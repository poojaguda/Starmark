const express=require("express");
const parser = require("body-parser")
const app=express();

app.use(parser.urlencoded({"extended":true}));
app.use(parser.json());

const config={
    server:'192.168.171.36',
    database:'3307',
    driver:'msnodesqlv8',
    options:{
        trustedConnection : true,
        TrustedServerCertificate : true
    }
}

const server=require('mssql/msnodesqlv8');
const pool=new server.ConnectionPool(config);

app.post("/",(req,res)=>{
    const body=req.body;
    const query=`INSERT INTO EMPLOYEE VALUES(${body.empid},'${body.empName}','${body.empAddress}',${body.empSalary})`;
    pool.connect().then(()=>{
        pool.request().query(query,(err,result)=>{
            if(err)
                console.log(err)
            else
                res.send("Employee inserted successfully")
        })
    }).catch((err)=>{
        console.error(err)
    })
})

app.get('/',(req,res)=>{
    pool.connect().then(()=>{
        pool.request().query("Select * FROM EMPLOYEE",(err, results)=>
        {
            if(err){
                console.error(err);
            }  
            else{
                res.send(results.recordset);
            }
        })
    }).catch((err)=>{
        if(err) {
            console.log(err);
        }  
    })
})

app.get('/',(req,res)=>{
    const id=parseInt(req.params.id);
        pool.connect().then(()=>{
            pool.request().query(`Select * FROM EMPLOYEE where EmpId = ${id}`,(err,result)=>{
                if(err){
                    console.error(err);
                }
                else{
                    res.send(results.recordset);
                }        
            })
        }).catch((err)=>{
            if(err) 
            {
                console.log(err);
            }
        })
})

app.delete('/:id',(req,res)=>{
    const id=parseInt(req.params.id);
        pool.connect().then(()=>{
            pool.request().query(`delete  FROM EMPLOYEE where EmpId = ${id}`,(err,results)=>{
                if(err){
                    console.error(err);
                }
                else{
                    res.send(results.recordset);
                }        
            })
        }).catch((err)=>{
            if(err) 
            {
                console.log(err);
            }
        })
})
app.listen(1275,() =>console.log("Server is available at 1275"));