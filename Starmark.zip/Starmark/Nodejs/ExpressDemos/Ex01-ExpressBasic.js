const express = require('express');
const parser=require('body-parser');
const app=express();

app.use(parser.urlencoded({extended:false}))

app.get('/',(req,res) =>res.send("Welcome to the Express Train"))

app.get('/Home',(req,res)=>res.sendFile(__dirname+'/Home.html'))
app.get('/Register',(req,res)=>res.sendFile(__dirname+'/Register.html'))

app.get('/AfterRegister',(req,res)=>{
    const name=req.query.txtName;
    const Email=req.query.txtEmail;
    res.send(`${name} is registered with us and will be contacted later with the email Address shared with us as ${Email}`)
})

app.post('/AfterRegister',(req,res)=>{
    if(req.body==null){
        res.send("The form does not contain body data in it");
    }else{
        const name=req.query.txtName;
        const Email=req.query.txtEmail;
        res.send(`${name} is registered with us and will be contacted later with the email Address shared with us as ${Email}`)
    }
})

app.listen(1234,() =>console.log("Server is available at 1234"));