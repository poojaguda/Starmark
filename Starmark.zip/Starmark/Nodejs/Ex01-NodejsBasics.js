console.log("Testing the Nodejs code");

const addFunc = (v1,v2)=>v1+v2;

console.log("The added value: " + addFunc(123,234));

const data=[
    {"id":1, "name":"Shru","address":"Davangere"},
    {"id":2, "name":"Bhatta","address":"Bangalore"},
    {"id":3, "name":"Jayappa","address":"Mumbai"},
    {"id":4, "name":"Siri","address":"Delhi"}
]

console.table(data);