const http=require("http");

http.createServer(function(req,res,err){
    if(err)
    console.error(err);
    console.log(req.url);
    if(req.url=="/Employees")
        res.write("Employees page of the Application")
    else if(req.url=="/Customers")
        res.write("Customers page of the Application")
    else
        res.write("Default page of the Application")
    res.end();
}).listen(1234)