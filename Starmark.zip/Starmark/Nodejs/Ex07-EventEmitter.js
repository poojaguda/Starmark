const emitter = require("events");
const { CLIENT_RENEG_LIMIT } = require("tls");
const eventClass=new emitter;

eventClass.on("insert",()=>{
    console.log("Insert event was triggered")
})

eventClass.on("delete",()=>{
    console.log("Delete event was triggered")
})

eventClass.on("click",(func)=>{
    func();
})

eventClass.emit("delete")//raising the event called delete

eventClass.emit("insert")
eventClass.emit("insert")
eventClass.emit("insert")


function onClick(){
    console.log("The button was clicked")
}
eventClass.emit("click",onClick)