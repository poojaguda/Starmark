const myModule = require("./CustomModule")

const alias = myModule.simpleFucn;

myModule.simpleFucn();

const a=myModule.mathTable();


const b=myModule.employee;

const empObj=new b(1,"shru","Bangalore");
empObj.display();