const os = require("os");
console.log(os.version());
console.log(os.hostname());
console.log(os.arch());

const cpusInfo=os.cpus();
    for(const info of cpusInfo){
        console.log(JSON.stringify(info))
    }
console.log(os.totalmem());//Displays the memory in GB......
console.log(os.freemem());
console.log(os.userInfo());

function covertMemory(){
    res= ((os.totalmem/1024)/1024)/1024;
    console.log(res,"GB")
}

console.log(covertMemory());