const fs= require("fs"); //for accessing the file system

const file = "./Ex02-ConsumingModule.js";

///////////////////////////////////////////Sync Reading///////////////////////////////////////

function readFileSync(){
    const contents = fs.readFileSync(file,"utf-8"); //utf-8 It is basic English with 8 bit character set

    console.log(contents);
}


///////////////////////////////////////Async Reading///////////////////////////////////

function readFileAsync(){
    fs.readFile(file,'utf-8', function(err,data){
        if(err)
            console.error(err);
        else
            console.log(data);
    })
}


///////////////////////////////Synch Writing//////////////////////////////////

const obj={"id":1,"name":"Shru"};
function writeToFile(){
    fs.writeFileSync("SampleText.txt",JSON.stringify(obj), "utf-8");
}

///////////////////////////////Asynch Writing/////////////////////////////////

function writeToFileAync(){
    fs.writeFile("SampleText.txt","sample text to write",(err)=>{
        if(err)
            console.error(err);
    })
}


function appendingToFile(){
    fs.appendFileSync("SampleText.txt", "\nContent will be appended in the next line\n","utf-8");
}


appendingToFile();
// readFileSync();
// readFileAsync();
//writeToFileAync();
//writeToFile();

//console.log("this code will execute after file reading")