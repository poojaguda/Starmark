const http = require('http');
const fs = require('fs');
const querystring=require('querystring');
const httpParse=require('url').parse;
const dir=__dirname; //const for the current directory of the Application
// console.log(dir)

function displayPage(res,url){
    const file=dir+url+".html";
    // console.log(file)
    fs.createReadStream(file).pipe(res)//It will read the stream data of the file 
    //and push the stream to the Respone and end the response
}



function errorPage(res){
    res.writeHead(200,{'Content-type':'text/html'});
    res.write("<h1 style='color:red'>OPPS something went wrong</h1>")
    res.write("<hr>")
    res.write("<h2>The Page requested is not available</h2>")
}

    http.createServer((req,res)=>{
        if(req.method=="GET"){
            const query=httpParse(req.url).query;
            if(query!=null){
                let obj =httpParse(req.url,true).query;
                const msg=`Thanks ${obj.txtName} for registering with Us! Ur Email ${obj.txtEmail} is registered and will be contacted`;
                res.write(msg);
                res.end();
                return;
            }
        }else if(req.method=="POST"){
            let postedData="";
            req.on("data",function(inputs){ //data is an event triggered when the page is posted
                res.write(inputs);
                postedData+=inputs;
            })
            req.on("end",function(){
                let post=querystring.parse(postedData);
                const msg=`Thanks Ms.${post['txtName']} for registering with Us! UR Email ${post['txtEmail']} is registered and will be contacted`;
                res.write(msg);
                res.end();
                return;
            })
        }


        //console.log(req.url)
        switch (req.url) {
            case "/favicon.ico":
                res.end();
                break;
            case "/Register":
                displayPage(res,req.url);
                break;
            case "/Home":
                displayPage(res,req.url);
                break;
            default:
                errorPage(res);
                res.end()
                break;
        }
    }).listen(2345); 
