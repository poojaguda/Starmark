 function convert(){
    
const celcius=document.getElementById("temp").value;
const fahreneit=(celcius*1.8+32);
alert(("Converted temperature is: ")+fahreneit);

}