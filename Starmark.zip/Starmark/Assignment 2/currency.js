function convert(){
    const v1=document.getElementById("amt1").value;
    switch{
        case India:
            if
    }
}