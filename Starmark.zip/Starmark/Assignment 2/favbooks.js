function add(){
    const books=[];
    let b=document.getElementById("book").value;
    books.push(b);
    const ol=document.getElementById("ol");
    for (let i=0;i<books.length;i++) {
        ol.innerHTML+="<li>"+books[i]+"</li>";
        console.log(books[i])
    }
}

