class details{
    constructor(username, mail){
    this.username=username;
    this.mail=mail;
    }
}

class form{
    array=[];
     addnewdetails=(a)=>this.array.push(a);

     displaydetails=()=>this.array;
}

const objdetails =  new form()

objdetails.addnewdetails(new details("shrusti","shrusti@nidhe.com"))
objdetails.addnewdetails(new details("hemanth","hemanth@nidhe.com"))
objdetails.addnewdetails(new details("deepu","deepu@nidhe.com"))

console.log(objdetails.displaydetails())