class calculato{
    add(a,b){
        return a+b;
    }
    sub(a,b){
        return a-b;
    }
    multi(a,b){
        return a*b;
    }
    div(a,b){
        return a/b;
    }
}

const obj=new calculato();

console.log(obj.add(3,2),
obj.sub(4,5),
obj.multi(5,6),
obj.div(8,4));