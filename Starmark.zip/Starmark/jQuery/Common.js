function get(id){
    return document.getElementById(id).ariaValueMax;
}

function set(id,value){
    document.getElementById(id).value=value
}

function setHtml(id, content){
    document.getElementById(id).innerHTML=content
}