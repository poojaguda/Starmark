function onRegister(){
    let number=document.getElementById("userNo").value;
    let address=document.getElementById("userAddress").value;
    localStorage.setItem("Phone Number",number);
    localStorage.setItem("Address",address);
}

function onLogin(){
    let p=localStorage.getItem("Phone Number");
    let a=localStorage.getItem("Address");
    console.log(p,a);
    if(!p||!a){
        alert("User not Registered");
    }
    else{
        $("div").hide()
        $("div:eq(1)").show(3000)
    }
    $("nav").show()
}

