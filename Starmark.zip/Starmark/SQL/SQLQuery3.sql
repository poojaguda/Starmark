--use [3307]

Create Procedure InsertEmployee
(
	@empName varchar(50),
	@empAddress varchar(MAX),
	@empSalary int,
	@deptId int,
	@managerID int,
	@empId int OUTPUT
)
AS
INSERT INTO tblEmployee values(@empName, @empAddress, @empSalary, @deptId)
SET @empId = @@IDENTITY

------------------CALLING THE STORED PROCDEURE---------------------
DECLARE @EmpId int

EXEC InsertEmployee
	@empName='Shivaram',
	@empAddress='Udupi',
	@empSalary=56000,
	@deptId=21,
	@managerID=1103,
	@empId = @EmpId OUTPUT

Select @EmpId as N'empId'

GO

select * from tblEmployee

