create table tblCustomer
(
CstId int primary key, CstName varchar(50) NOT NULL, CstAddress varchar(200)NOT NULL,
BillDate date Default Getdate(), BillAmount money
)

create table Customer_Audit
(
	id int primary key identity(1,1),
	details varchar(200) NOT NULL
)

----------------------------insert-----------------------------
create Trigger OnInsertCustomer
on tblCustomer
for insert
AS
begin
declare @id int
select @id = CstId from inserted
Insert into Customer_Audit Values('Customer with Id ' + (CAST(@id as varchar)) + 'is inserted into Database on' 
+ cast(GETDATE() as varchar(50)))
END

Insert into tblCustomer values(111,'TestName','Bangalore','12/12/2022',5600)
Insert into tblCustomer values(112,'Lekha Raju','Andman','2000/02/29',1)

select * from Customer_Audit

------------------------DELETE------------------------------
create Trigger OnDeleteCustomer
on tblCustomer
after delete
as
begin
declare @id int
select @id=CstId from deleted
insert into Customer_Audit Values('Customer with ID'+(cast (@id as varchar)) + 'is deleted from
Database on'+Cast(getdate() as varchar(50)))
end

delete from tblCustomer where CstId =111
 
 ----------------------------Update---------------------------
create trigger OnUpdateTrigger
on tblCustomer
after update
as
begin
declare @id int
declare @oldName varchar(50)
declare @newName varchar(50)
select @id = CstId from inserted
select @oldName = CstName from deleted
select @newName= CstName from inserted
insert into Customer_Audit Values('Customer with Id' + (cast(@id as varchar))+ ' is updated with' + @newName +
'replacing the' +@oldName+'on'+cast(getdate() as varchar))
end

select * from tblCustomer
update tblCustomer set CstName='Gopal' where CstId=111
update tblCustomer set CstName='Siri' where CstId=112