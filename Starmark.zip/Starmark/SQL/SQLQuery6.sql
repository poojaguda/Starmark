select distinct  EmpAddress from tblEmployee

select  * from tblEmployee where EmpAddress in ('Bangalore', 'Denver','Manglore')
select  * from tblEmployee where EmpAddress not in ('Bangalore', 'Denver','Manglore')

create table tblContact(contactId int primary key identity(1,1), contactName varchar(50) 
Not null, contactCity varchar(200)not null)

insert into tblContact(contactName, contactCity)
select EmpName, Empaddress from tblEmployee where EmpId<= 10500

delete top(25) percent from tblEmployee where EmpAddress = 'Paris 20'

select * from tblEmployee

delete t1 from tblEmployee t1
Inner join tblEmployee t2 on t1.EmpId=t2.EmpID
where t2.EmpAddress in(select top(25) percent EmpAddress from tblEmployee where 
EmpAddress='Bangalore' order by EmpAddress desc)

select EmpName from tblEmployee UNION all select tblContact.contactName from tblContact

select 'TotalSalary' AS TotalSalariesByDept, [21],[25]
From(select Department, EmpSalary from tblEmployee) as SourceTable
PIVOT
(
	SUM(EmpSalary)for Department in([21],[25])
)AS PivotTable

select EmpName,EmpSalary, SUM(EmpSalary) OVER() TotalSalaries
from tblEmployee
where Department = 22