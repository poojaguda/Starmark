create function GetDept(@id int)
RETURNS varchar(50)
AS
BEgin
Declare @deptName varchar(50)
Set @depName = (SELECT tblDept.DeptName from tblDept WHERE DeptId = @id)
RETURN @deptName
END

PRINT dbo.GetDepet(4)
SELECT dbo.GetDept(4)


--------------------------------DATE-------------------------------
create function CreateDate(@date Date)
returns varchar(20)
as
begin
declare @retVal varchar(20)
set @retVal=' '+DATENAME(day,@Date)+' '+DATENAME(month, @Date)+' '+DATENAME(year, @Date)
return @retVal
END

print dbo.CreateDate(getdate())

--------------------------------DOB--------------------------------------
Create function GetAge(@dob Date)
returns int
as begin
declare @age int=0
set @age = DATEDIFF(year, @dob, GETDATE());
RETURN @age
end

print dbo.GetAge('1975/05/16')