sp_databases

use [3307]

sp_tables

sp_columns tblEmployee

print @@version

Drop table employee


Create table tblEmployee
(
	EmpID int PRIMARY KEY IDENTITY(1001,1),
	EmpName varchar(50) NOT NULL,
	EmpAddress varchar(MAX) NOT NULL,
	EmpSalary money NOT NULL
)

Insert into tblEmployee values('Shru','Bangalore',652000,21);
Insert into tblEmployee values('Bharath','Mangalore',952000,22);
Insert into tblEmployee values('Deepu','Davangere',842000,23);
Insert into tblEmployee values('Jack','US',98521,24);
Insert into tblEmployee values('Marie','UK',563000,25);
Insert into tblEmployee values('Dustin','Europe',741000,26);

delete from tblEmployee where EmpId = 1004


select * from tblEmployee

Create table tblDept
(
	DeptId int primary key identity(1,1),
	DeptName varchar(50)NOT NULL
)

-------------Altering the table-------------

ALTER TABLE tblEmployee
ADD DeptId int NULL
REFERENCES tblDept(DeptId)


alter table tblEmployee
--drop constraint FK__tblEmploy__DeptI__3C69FB99
drop column DeptId


Insert into tblDept values('Development')
Insert into tblDept values('Human Resources')
Insert into tblDept values('IT Help Desk')
Insert into tblDept values('Transport')
Insert into tblDept values('Management')
Insert into tblDept values('Utilities')

select * from tblDept


Alter table tblEmployee Add Department int NULL References tblDept(DeptId)

update tblEmployee set Department = 21 where EmpName = 'Shru'
update tblEmployee set Department = 22 where EmpName = 'Bharath'
update tblEmployee set Department = 23 where EmpName = 'Deepu'
update tblEmployee set Department = 24 where EmpName = 'Jack'
update tblEmployee set Department = 25 where EmpName = 'Marie'
update tblEmployee set Department = 26 where EmpName = 'Dustin'

delete from tblEmployee where EmpId < 2000
delete from tblEmployee where Department = 5

select * from tblEmployee
truncate table tblEmployee
select * from tblEmployee


select count(*) from tblEmployee