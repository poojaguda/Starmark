use[3307]
select * From tblEmployee

select * from tblDept

SELECT EmpName, EmpSalary from  tblEmployee

Select MAX(EmpSalary) AS MaxSalary, 
MIN(EmpSalary) as MinSalary, 
AVG(EmpSalary) as AvgSalary from tblEmployee

select EmpName from tblEmployee WHERE EmpAddress='US'

select EmpName from tblEmployee WHERE EmpName like 'A%'

select EmpName, DeptId from tblDept, tblEmployee WHERE DeptId is NOT NULL

select EmpName, COALESCE(Department, 0) as DEPTINFO from tblEmployee 
WHERE Department IS NULL

Select EmpName, ISNULL(Department, 0) as DEPTINFO from tblEmployee

select top(10) EmpName, tblEmployee.EmpSalary from tblEmployee 
where EmpSalary between 30000 and 70000 order by empSalary

select * from tblEmployee where EmpAddress = 'UK' or EmpSalary < 50000

SELECT EmpName, EmpSalary FROM tblEmployee WHERE EmpAddress = 'Damai' OR EmpAddress = 'Bangalore'

SELECT TOP 50 PERCENT * FROM tblEmployee

--------------------SELECT ORDER BY--------------------------------
SELECT tblEmployee.EmpName FROM tblEmployee ORDER BY EmpName

SELECT tblEmployee.EmpName FROM tblEmployee ORDER BY EmpName DESC

SELECT TOP(5) EmpName From tblEmployee WHERE EmpAddress = 'mangalore' ORDER BY EmpName

--------------------SELECT JOINS--------------------------------

--Combining 2 table data on common clause is called INNER JOIN
SELECT EmpName, tblDept.DeptName from tblEmployee JOIN tblDept
ON tblEmployee.Department = tblDept.DeptId

------------------LEFT JOIN is all records of the left table and matching records of right table
Select tblEmployee.*, tblDept.DeptName from tblEmployee LEFT JOIN tblDept
ON tblEmployee.Department = tblDept.DeptId

--------------------Right JOIN is opposite of Left Join. 
Select tblEmployee.*, tblDept.DeptName from tblEmployee RIGHT JOIN tblDept
ON tblEmployee.Department = tblDept.DeptId

--get the deptname and max salary of each dept. 
Select tblDept.DeptName, MAX(tblEmployee.EmpSalary) From tblEmployee 
RIGHT JOIN tblDept
ON tblEmployee.Department = tblDept.DeptId
group by tblDept.DeptName

-- get the DeptName and Total Salaries of that dept.
Select tblDept.DeptName, SUM(tblEmployee.EmpSalary) as sum From tblEmployee 
RIGHT JOIN tblDept
ON tblEmployee.Department = tblDept.DeptId
group by tblDept.DeptName

-- Get EmpNames and DeptNames grouped and order by DeptName
Select tblEmployee.EmpName, tblDept.DeptName from tblEmployee 
JOIN tblDept ON tblEmployee.Department = tblDept.DeptId
GROUP BY tblEmployee.EmpName, tblDept.DeptName
ORDER BY tblDept.DeptName ASC

-- Get the EmpName, EmpSalary, DeptName on DeptID

--------------Self Join-------------
Alter table tblEmployee
Add ManagerId int 
REFERENCES tblEmployee(EmpId)

Update tblEmployee 
Set ManagerId = 1006 
Where EmpId < 1200 AND EmpId > 1176
SELECT
    employee.EmpId,
        employee.EmpName,
        employee.ManagerId,
        manager.EmpName as ManagerName
FROM tblEmployee employee
JOIN tblEmployee manager
ON employee.ManagerId = manager.EmpId 
SELECT * FROM tblEmployee
DECLARE @id INT = 1004
IF (SELECT TOP(1) EmpID from tblEmployee) > @id
BEGIN
	Update tblEmployee
	set ManagerId = (SELECT (EmpId % 5) + 1 FROM tblEmployee)
END




